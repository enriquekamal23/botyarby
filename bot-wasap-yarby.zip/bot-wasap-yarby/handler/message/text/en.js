exports.textTnC = () => {
    return `
El bot es un programa de código abierto (gratuito) escrito con Javascript,lo puedes usar, copiar, modificar, combinar, publicar, distribuir, sublicenciar o vender copias sin eliminar el autor principal del código fuente / bot
 . Al utilizar este código fuente / bot, acepta los siguientes Términos y condiciones: 
- El código fuente no almacena sus datos en nuestros servidores. - El código fuente / bot no es responsable de los stickers que usted crea con este bot y los videos, imágenes y otros datos que obtiene del código fuente / bot. 
- El bot no se puede utilizar para servicios que tienen como objetivo:
    • sexo/ trafico de personas.
    • comportamiento adictivo dañino.
    • crímenes.
    • violencia (a menos que sea necesario para proteger la seguridad pública).
    • incitación al odio o discriminación por motivos de edad, sexo, identidad de género, raza, sexualidad, religión, nacionalidad.


Atentamente, Yarby :).`
}

exports.textMenu = (pushname) => {
    return `
Hey, ${pushname || ''}! 👋️
¡Estas son algunas de las características de este bot!✨

Sticker Maker:
1. *#sticker*
Para convertir una imagen en un sticker, envíe la imagen con el título #sticker o responda a la imagen que se envió con #sticker.

2. *#stickers* _<Image Url>_
Para cambiar la imagen de la URL a un sticker.

3. *#gifsticker* _<Giphy URL>_ / *#stickergif* _<Giphy URL>_
Para convertir un gif en un sticker(solo Giphy)

Descargar:
1. *#tiktok* _<post / video url>_
Devolverá video tiktok.

2. *#fb* _<post / video url>_
Devolverá el enlace de descarga del video de Facebook.

3. *#ig* _<post / video url>_
Devolverá el enlace de descarga del video de Instagram.

4. *#twt* _<post / video url>_
Devolverá el enlace de descarga de video de Twitter.

Etc:
1. *#tnc*
Muestra los términos y condiciones del bot.

Espero que tengas un gran día!✨`
}

exports.textAdmin = () => {
    return `
⚠ [ *SOLO PARA ADMINS* ] ⚠ 
Estas son algunas de las funciones de administración de grupo incluidas en este bot.

1. *#kick* @usuario
Eliminar miembros del grupo (puedes mencionar a mas de 1).

2. *#promote* @usuario
Asciende miembros a administradores de grupo.

3. *#demote* @usuario
Degradar administradores de grupo.

3. *#tagall*
Menciona a todos los miembros del grupo.`
}
